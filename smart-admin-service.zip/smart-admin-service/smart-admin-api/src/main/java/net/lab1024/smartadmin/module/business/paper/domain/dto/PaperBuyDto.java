package net.lab1024.smartadmin.module.business.paper.domain.dto;

import lombok.Data;

@Data
public class PaperBuyDto {
	
	private String paperNumber;
	private Long FaceValue;
	private String owner;
}
