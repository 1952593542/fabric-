package net.lab1024.smartadmin.module.business.paper.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.milagro.amcl.RSA2048.public_key;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import javassist.expr.NewArray;
import net.lab1024.smartadmin.common.domain.PageResultDTO;
import net.lab1024.smartadmin.common.domain.ResponseDTO;
import net.lab1024.smartadmin.module.business.paper.dao.PaperDao;
import net.lab1024.smartadmin.module.business.paper.dao.PaperFabricDao;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperBuyDto;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperIssueDto;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperQueryDTO;
import net.lab1024.smartadmin.module.business.paper.domain.entity.PaperEntity;
import net.lab1024.smartadmin.module.business.paper.domain.vo.PaperVo;
import net.lab1024.smartadmin.util.SmartBeanUtil;
import net.lab1024.smartadmin.util.SmartPageUtil;

@Service
public class PaperService {

	@Autowired
	private PaperDao paperDao;
	
	public ResponseDTO<PageResultDTO<PaperVo>> queryByPage(PaperQueryDTO queryDTO) {
//		Page page = SmartPageUtil.convert2QueryPage(queryDTO);
//		IPage<PaperVo> voList = paperDao.queryByPage(page, queryDTO);
//		PageResultDTO<PaperVo> pageResultDTO = SmartPageUtil.convert2PageResult(voList);	

		PageResultDTO<PaperVo> pageResultDTO2  = new PageResultDTO<PaperVo>();

		pageResultDTO2.setList(PaperFabricDao.queryList());
		pageResultDTO2.setTotal((long) PaperFabricDao.queryList().size());
		
		return ResponseDTO.succData(pageResultDTO2);
	}
	
	public ResponseDTO<String> issue(PaperIssueDto issueDto) {
//		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        System.out.println(df.format(new Date()));// new Date()为获取当前系统时间
        
		issueDto.setIssueDateTime(new Date());
		PaperEntity entity = SmartBeanUtil.copy(issueDto, PaperEntity.class);
//		paperDao.insertPaper(entity);
		entity.setIssueDateTime(df.format(new Date()));
		entity.setMaturityDateTime(df.format(issueDto.getMaturityDateTime()));
		
		boolean flag = true;
		try {
			flag = IssueHelper.issue(entity.getIssuer(), entity.getPaperNumber(),
					entity.getIssueDateTime(), entity.getMaturityDateTime(),
					entity.getFaceValue().toString());
			if(flag) {
//				paperDao.insert(entity);				
			}
			return ResponseDTO.succ();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseDTO.error();
		}
		
		
	}
	
	//PaperBuyDto buyDto
	public ResponseDTO<String> trading(PaperIssueDto tradingDto) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				
		PaperEntity entity = SmartBeanUtil.copy(tradingDto, PaperEntity.class);
//		entity.setIssueDateTime(df.format(buyDto.getIssueDateTime()));
//		entity.setMaturityDateTime(df.format(buyDto.getMaturityDateTime()));
		System.out.println(tradingDto);
		System.out.println(tradingDto.toString());
				
		entity.setIssueDateTime(df.format(tradingDto.getIssueDateTime()));
		entity.setMaturityDateTime(df.format(tradingDto.getMaturityDateTime()));
		System.out.println(entity.toString());
		
		boolean flag = true;
		try {
			// String issuer,String paperNumber,String currentOwner,
    		// String newOwner,String price,String purchaseDateTime
			flag = BuyHelper.buy(entity.getIssuer(), entity.getPaperNumber(), "MagnetoCorp",
					entity.getOwner(), entity.getFaceValue().toString(), 
					df.format(new Date()).toString());
			if(flag) {
				paperDao.tradingByPaperNumber(entity);
			}
			return ResponseDTO.succ();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseDTO.error();
		}
	}
	
	public ResponseDTO<String> redeem(PaperIssueDto redeemDto) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		PaperEntity entity = SmartBeanUtil.copy(redeemDto, PaperEntity.class);
		entity.setIssueDateTime(df.format(redeemDto.getIssueDateTime()));
		entity.setMaturityDateTime(df.format(redeemDto.getMaturityDateTime()));
		System.out.println(entity);
		
		boolean flag = true;
		try {
			//String issuer,String paperNumber,String redeemingOwner,String redeemDateTime
			flag = RedeemHelper.redeem(entity.getIssuer(), entity.getPaperNumber(), 
					entity.getOwner(), df.format(new Date()).toString());
			if(flag) {
				paperDao.redeemByPaperNumber(entity);
			}
			return ResponseDTO.succ();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseDTO.error();
		}
	}
	
	
	
	
	
}
