package net.lab1024.smartadmin.module.business.paper.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;

import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperQueryDTO;
import net.lab1024.smartadmin.module.business.paper.domain.entity.PaperEntity;
import net.lab1024.smartadmin.module.business.paper.domain.vo.PaperVo;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.milagro.amcl.RSA2048.public_key;
import org.springframework.stereotype.Component;


@Mapper
@Component
public interface PaperDao extends BaseMapper<PaperEntity>{
	
	IPage<PaperVo> queryByPage(Page page, @Param("queryDTO") PaperQueryDTO queryDTO);
	
//	public void insertPaper(PaperEntity entity);
	
	public void tradingByPaperNumber(@Param("entity") PaperEntity entity);
	
	public void redeemByPaperNumber(@Param("entity") PaperEntity entity);
}
