package net.lab1024.smartadmin.module.business.paper.dao;

import lombok.Data;
import net.lab1024.smartadmin.module.business.paper.domain.vo.PaperVo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.alibaba.druid.sql.ast.statement.SQLIfStatement.Else;
import com.alibaba.druid.sql.visitor.functions.If;

//import com.alibaba.fastjson.JSON;  
//import com.alibaba.fastjson.JSONArray;  
//import com.alibaba.fastjson.JSONObject; 

@Data
public class PaperFabricDao {
	
	/**
	 * 记录总数
	 */
//	private Long totleLong = 0L;
	
	/**
	 * 票据总数
	 */
//	private int paperCount = 0;
	
	/**
	 * @author 1952593542
	 * @time 2021-12-28
	 * @return 返回记录集合
	 */
	public static List<PaperVo> queryList() {
		
		List<PaperVo> list = new ArrayList<PaperVo>();
//		String[] strings = queryPartial("MagnetoCorp");
//		for (int i = 0; i < strings.length; i++) {
//			if(strings[i].equals("")) {
//				byte[] response = qureyAllPaper.queryHistory("MagnetoCorp", strings[i]);
//				PaperVo[] pvs = serialize(response, true);
//				
//				for (int j = 0; j < pvs.length; j++) {
//					list.add(pvs[j]);
//				}
//			}
		byte[] response = qureyAllPaper.queryNamed("value");
		PaperVo[] pvs = serialize(response, true);
		if(pvs == null) {
			return list;
		}
		System.out.println("pvs = " + pvs.toString());
		System.out.println("pvs.length = " + pvs.length);
		for (int j = 0; j < pvs.length; j++) {
//			if(!pvs[j].getPaperNumber().equals("")) { //避免查到空记录
			if(pvs[j] != null) {
				list.add(pvs[j]);
			}
			
		}
		return list;
	}

//	/**
//	 * 返回查询记录，序列化后添加到list集合内
//	 * @author 1952593542
//	 * @time 2021-12-28 0:46
//	 * @param issuer
//	 * @param paperNumber
//	 * @return
//	 */
//	public byte[] queryHistory(String issuer, String paperNumber) {
//		return PaperFabricDaoHelper.queryHistory(issuer, paperNumber);
//	}
	
	/**
	 * 白写了，不过有nullPointException，难找bug。废弃不用正好 hahaha
	 * @param prefix 组织名
	 * @return 通过组织名得到对应的票据列表
	 */
	@Deprecated
	public static String[] queryPartial(String prefix) {
		String[] strings = null;
		byte[] response = PaperFabricDaoHelper.queryPartial(prefix);
//		PaperVo[] pvs = serialize(response, false);
		PaperVo[] pvs = new PaperVo[serialize(response, false).length];
		for (int i = 0; i < pvs.length; i++) {
			PaperVo pv = new PaperVo();
			pvs[i] = pv;
		}
		System.out.println("---queryPartial test--");
		System.out.println("pvs.length = " + pvs.length);
		System.out.println(pvs.toString());
		pvs = serialize(response, false);
//		System.out.println("输出pvs");
//		for (PaperVo paperVo : pvs) {
//			System.out.println("我是foreach内的 pvs = " + paperVo.toString());			
//		}
		
		strings = new String[pvs.length];
		
		for (int i = 0; i < pvs.length; i++) {
			
			if(pvs[i].getPaperNumber().equals("")) {
				String s1 = "";
				strings[i] = s1;
			} else {
				String s1 = new String(pvs[i].getPaperNumber());
				strings[i] = s1;
			}							
		}
		System.out.println("strings = " + strings);
		
		return strings;
	}

	
	/**
	 * 
	 * @param response json数据流
	 * @param isRecords 是否是记录
	 * @return 返回值为一个数组，若只有一条记录，则有两个记录，后面的为空。 >2正常
	 */
	public static PaperVo[] serialize(byte[] response, boolean isRecords) {
//		PaperVo[] paperVos = null; // nullPointerException
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");// 设置日期格式

		try {
			JSONArray jsonArray = new JSONArray(new String(response));
			System.out.println(jsonArray.toString());
			int size = jsonArray.length();
			System.out.println(size);
			if(size == 0) {
				return null;
			}
			// 如果是要统计的记录，才进行计数
//			if(isRecords) {
//				this.totleLong += (long) size;
//			} else {
//				this.paperCount++;
//			}

			if (size <= 1) {				
				PaperVo[] paperVos = new PaperVo[2];
				System.out.println(paperVos[1]); //null
				System.out.println("--1--");
				
				try {
					for (int i = 0; i < size; i++) { //size == 1, only with a record
						paperVos[i] = new PaperVo();
						JSONObject jo = jsonArray.getJSONObject(i);
						System.out.println(jo.toString());
						System.out.println("--2--");
						
						JSONObject jsonObject = jo.getJSONObject("Record");
						System.out.println(jsonObject.toString());
						System.out.println("--3--");
						System.out.println("----test begin --");
						
						String s1 = "123";
						switch(jsonObject.getInt("currentState")) {
							case 1:
								s1 = "ISSUED";
								break;
							case 2:
								s1 = "PENDING";
								break;
							case 3:
								s1 = "TRADING";
								break;
							case 4:
								s1 = "REDEEMED";
								break;
							default:
								s1 = "undefined State";
						}
						System.out.println("paperVos[i] = " + paperVos[i]); // null
						paperVos[i].setState(s1);
						System.out.println("--4--");
						paperVos[i].setFaceValue(jsonObject.getLong("faceValue"));
						System.out.println("--5--");
						paperVos[i].setIssueDateTime(df.parse(jsonObject.getString("issueDateTime")));
						System.out.println("--6--");
						paperVos[i].setIssuer(jsonObject.getString("issuer"));
						System.out.println("--7--");
						paperVos[i].setMaturityDateTime(df.parse(jsonObject.getString("maturityDateTime")));
						System.out.println("--8--");
						paperVos[i].setOwner(jsonObject.getString("owner"));
						System.out.println("--9--");
						paperVos[i].setPaperNumber(jsonObject.getString("paperNumber"));
						System.out.println("--10--");
						System.out.println(paperVos[i].toString());
					}
				} catch (Exception e) {
					return paperVos;
				}
				
				return paperVos; // paperVos[2] = null;
			} else {
				System.out.println("----test begin --");
				PaperVo[] paperVos = new PaperVo[size];
				System.out.println("--1--");

				for (int i = 0; i < size; i++) {
					paperVos[i] = new PaperVo();
					JSONObject jo = jsonArray.getJSONObject(i);
					System.out.println(jo.toString());
					System.out.println("--2--");
					JSONObject jsonObject = jo.getJSONObject("Record");
					System.out.println(jsonObject.toString());
					System.out.println("--3--");

					String s1 = "123";
					switch(jsonObject.getInt("currentState")) {
						case 1:
							s1 = "ISSUED";
							break;
						case 2:
							s1 = "PENDING";
							break;
						case 3:
							s1 = "TRADING";
							break;
						case 4:
							s1 = "REDEEMED";
							break;
						default:
							s1 = "undefined State";
					}
					paperVos[i].setState(s1);
					System.out.println("--4--");
					paperVos[i].setFaceValue(jsonObject.getLong("faceValue"));
					paperVos[i].setIssueDateTime(df.parse(jsonObject.getString("issueDateTime")));
					paperVos[i].setIssuer(jsonObject.getString("issuer"));
					paperVos[i].setMaturityDateTime(df.parse(jsonObject.getString("maturityDateTime")));
					paperVos[i].setOwner(jsonObject.getString("owner"));
					paperVos[i].setPaperNumber(jsonObject.getString("paperNumber"));
					System.out.println(paperVos[i].toString());
				}
				return paperVos; // all records is unEmpty
			}	
		} catch (Exception e) {
			System.out.println("JSON转换错误 - begin:");
			e.printStackTrace();
			System.out.println("JSON转换错误 - end:");
		}
		
		return null;
	}
}
