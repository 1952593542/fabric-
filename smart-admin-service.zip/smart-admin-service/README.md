### 部署说明

#### 下载代码

smart-admin-service

将两个项目导入idea

#### 创建数据库

先执行：src/main/resources/sql/smart-admin.sql

再执行：src/main/resources/sql/quartz_mysql_2.3.0.sql

#### 启动

运行 smart-admin-api项目 SmartAdminApplication类
